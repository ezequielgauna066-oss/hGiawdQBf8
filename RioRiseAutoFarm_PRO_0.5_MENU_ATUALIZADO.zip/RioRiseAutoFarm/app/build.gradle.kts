plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.rioriseautofarm"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.rioriseautofarm"
        minSdk = 23
        // Target 28 keeps this lightweight prototype compatible with older
        // overlay/foreground-service behavior while it is being validated.
        targetSdk = 28
        versionCode = 3
        versionName = "0.3"
    }
}
