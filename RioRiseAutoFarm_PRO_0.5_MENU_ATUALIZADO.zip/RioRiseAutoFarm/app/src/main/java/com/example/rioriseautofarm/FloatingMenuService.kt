package com.example.rioriseautofarm

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class FloatingMenuService : Service() {
    private lateinit var windowManager: WindowManager
    private var rootView: LinearLayout? = null
    private var params: WindowManager.LayoutParams? = null
    private var minimized = false
    private val channelId = "rio_rise_overlay"

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        if (rootView == null) showPanel()
        return START_STICKY
    }

    private fun startAsForeground() {
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(NotificationChannel(
                channelId, "RIO RISE AUTO FARM", NotificationManager.IMPORTANCE_LOW
            ))
        }
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, channelId) else {
                @Suppress("DEPRECATION") Notification.Builder(this)
            }
        startForeground(31, builder.setContentTitle("RIO RISE AUTO FARM PRO")
            .setContentText("Menu flutuante em execução")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true).build())
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun text(value: String, size: Float, color: Int) = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
    }

    private fun showPanel() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(Color.rgb(22, 27, 39))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val heading = text("RIO RISE  •  PRO", 16f, Color.WHITE).apply {
            setPadding(0, 0, dp(8), 0)
        }
        val spacer = View(this).apply { }
        val minimize = Button(this).apply {
            text = "—"
            textSize = 15f
            setOnClickListener { showBubble() }
        }
        val close = Button(this).apply {
            text = "×"
            textSize = 18f
            setOnClickListener { stopSelf() }
        }
        header.addView(heading, LinearLayout.LayoutParams(0, dp(44), 1f))
        header.addView(minimize)
        header.addView(close)
        card.addView(header)

        val hint = text("MENU FLUTUANTE  •  ARRASTE PELO TÍTULO", 10f,
            Color.rgb(150, 165, 190)).apply { setPadding(0, 0, 0, dp(10)) }
        card.addView(hint)

        addSection(card, "MOVIMENTAÇÃO")
        addToggle(card, "AUTO RUN")
        addSection(card, "RECURSOS")
        addToggle(card, "AUTO MINE")
        addToggle(card, "AUTO COLLECT")

        val footer = text("Controles demonstrativos — ainda não automatizam jogos.",
            10f, Color.rgb(255, 205, 120)).apply { setPadding(0, dp(12), 0, 0) }
        card.addView(footer)

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else {
                @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
            }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12); y = dp(110)
        }

        header.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = sx + (e.rawX - tx).toInt()
                        lp.y = sy + (e.rawY - ty).toInt()
                        windowManager.updateViewLayout(card, lp)
                        return true
                    }
                }
                return false
            }
        })
        params = lp
        rootView = card
        windowManager.addView(card, lp)
    }

    private fun addSection(parent: LinearLayout, title: String) {
        parent.addView(text(title, 11f, Color.rgb(110, 190, 255)).apply {
            setPadding(0, dp(10), 0, dp(4))
        })
    }

    private fun addToggle(parent: LinearLayout, label: String) {
        var active = false
        val button = Button(this).apply {
            text = "$label   •   DESLIGADO"
            isAllCaps = false
            setOnClickListener {
                active = !active
                text = "$label   •   ${if (active) "LIGADO" else "DESLIGADO"}"
            }
        }
        parent.addView(button)
    }

    private fun showBubble() {
        val old = rootView ?: return
        val lp = params ?: return
        try { windowManager.removeView(old) } catch (_: Exception) { }
        val bubble = Button(this).apply {
            text = "RIO"
            textSize = 12f
            setOnClickListener {
                try { windowManager.removeView(this) } catch (_: Exception) { }
                rootView = null
                showPanel()
            }
        }
        rootView = LinearLayout(this).apply {
            addView(bubble, LinearLayout.LayoutParams(dp(58), dp(52)))
        }
        minimized = true
        windowManager.addView(rootView, lp)
    }

    override fun onDestroy() {
        rootView?.let { try { windowManager.removeView(it) } catch (_: Exception) { } }
        rootView = null
        stopForeground(true)
        super.onDestroy()
    }
}
