package com.example.rioriseautofarm

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 36, 28, 28)
            setBackgroundColor(Color.rgb(15, 18, 27))
        }

        val title = TextView(this).apply {
            text = "RIO RISE AUTO FARM"
            textSize = 25f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "PAINEL DE CONTROLE PRO 0.5"
            textSize = 13f
            setTextColor(Color.rgb(165, 180, 205))
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 28)
        }
        status = TextView(this).apply {
            text = "Status: aguardando autorização"
            textSize = 14f
            setTextColor(Color.rgb(220, 228, 240))
            setPadding(0, 8, 0, 22)
        }

        fun actionButton(label: String, action: () -> Unit) =
            Button(this).apply {
                text = label
                isAllCaps = false
                setOnClickListener { action() }
            }

        root.addView(title)
        root.addView(subtitle)
        root.addView(status)
        root.addView(actionButton("1 • Permitir menu sobre outros apps") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            } else status.text = "Status: autorização concedida"
        })
        root.addView(actionButton("2 • Abrir menu flutuante") {
            if (Settings.canDrawOverlays(this)) {
                startService(Intent(this, FloatingMenuService::class.java))
                status.text = "Status: menu iniciado"
            } else status.text = "Autorize a sobreposição primeiro"
        })
        root.addView(actionButton("Parar menu flutuante") {
            stopService(Intent(this, FloatingMenuService::class.java))
            status.text = "Status: menu parado"
        })

        val note = TextView(this).apply {
            text = "As opções AUTO RUN, AUTO MINE e AUTO COLLECT são controles visuais demonstrativos nesta versão. Ainda não executam ações dentro dos jogos."
            textSize = 12f
            setTextColor(Color.rgb(255, 205, 120))
            setPadding(4, 26, 4, 0)
        }
        root.addView(note)
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized && Settings.canDrawOverlays(this)) {
            status.text = "Status: autorização concedida"
        }
    }
}
